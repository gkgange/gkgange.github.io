#!/usr/bin/env python
import pickle
import xgboost

def integral_domain(dom):
  try:
    return list(map(int, dom))
  except ValueError:
    return range(len(dom))

# soybean/soybean_data_nbestim_50_maxdepth_3_testsplit_0.2.mod.pkl
# soybean/soybean_data_nbestim_50_maxdepth_3_testsplit_0.2.mod.pkl.splitdata.pkl
if __name__ == '__main__':
    import argparse
    
    parser = argparse.ArgumentParser(description='Convert an xgboost model into minizinc.')
    parser.add_argument('data', type=str,
                    help='(pickled) xgboost data.')
    parser.add_argument('out_prefix', type=str,
                    help='output filename prefix')

    args = parser.parse_args()

    with open(args.data, 'rb') as buf:
        data = pickle.load(buf)

    features = [ f for f in data['feature_names'] ]

    X = data['X']
    row_len = len(str(len(X)))
    row_num = 0
    for row in X:
        row_name = str(row_num).zfill(row_len)
        out_fname = "{}.{}.dzn".format(args.out_prefix, row_name)
        row_num += 1
        with open(out_fname, 'w') as buf:
            print("hyp_feature = {};".format(features), file=buf)
            print("hyp_val = {};".format(list(map(int, row))), file=buf)
