#!/bin/bash
## Run core-boosted version
TIMEOUT=600

JOBFILE=$1
shift

DATE=`date +%F-%H.%M`
RESULTS=results.${DATE}
OUTDIR=output.${DATE}

if [ -d ${OUTDIR} ]
then
  rm -rf ${OUTDIR}
fi
mkdir ${OUTDIR}

xargs -n 4 -P 1 ./run-job.sh ${OUTDIR} ${TIMEOUT} < ${JOBFILE} | tee ${RESULTS}
