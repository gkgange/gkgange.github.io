#!/usr/bin/env python
import pickle
import xgboost

def make_subtree(dframe, fmap, r, depth = 1):
    row = dframe[dframe.ID==r].iloc[0]
    if row.Feature == 'Leaf':
        return "round(Scale * {})".format(row.Gain)
    else:
        (feat, val) = fmap[row.Feature]
        return "[{0}\n{4},{1}]\n{4}[ 1 + (fval[{2}] = {3})]".format(
            make_subtree(dframe, fmap, row.Yes, depth+1),
            make_subtree(dframe, fmap, row.No, depth+1),
            feat,
            val,
            "  "*depth)

def make_tree(dframe, fmap, t):
    return make_subtree(dframe, fmap, str(t) + "-0")

# Data domain is always indexed from 0.
def integral_domain(dom):
  #try:
  #  return list(map(int, dom))
  #except ValueError:
  #  return range(len(dom))
  return range(len(dom))

# soybean/soybean_data_nbestim_50_maxdepth_3_testsplit_0.2.mod.pkl
if __name__ == '__main__':
    import argparse
    
    parser = argparse.ArgumentParser(description='Convert an xgboost model into minizinc.')
    parser.add_argument('model', type=str,
                    help='(pickled) xgboost model.')
    parser.add_argument('data', type=str,
                    help='(pickled) sample data.')

    args = parser.parse_args()

    with open(args.model, 'rb') as buf:
        model = pickle.load(buf)
    with open(args.data, 'rb') as buf:
        data = pickle.load(buf)

    params = model.get_xgb_params()
    booster = model.get_booster()

    dframe = booster.trees_to_dataframe()
    # Estimators-per class
    trees_per_class = params['n_estimators']

    trees = dframe['Tree'].unique()
    num_classes = round(len(trees) / trees_per_class)

#    class_trees = [
#        [ trees[num_classes * j + c] for j in range(trees_per_class) ]
#        for c in range(num_classes) ]

    features = [ "'" + f + "'" for f in data['feature_names'] ]
    domains = data['categorical_names']
    # Coerce the domains to int sets.
    domains = { f : integral_domain(domains[f]) for f in domains }

    # Map Boolean features to (feature, value) pairs
    fmap = {}
    fnum = 0
    for f in range(len(features)):
        ident = features[f]
        if f not in domains:
            # Boolean feature
            fmap['f' + str(fnum)] = (ident, 1)
            fnum += 1
            domains[f] = { 0, 1 }
        else:
            # Categorical feature.
            for v in domains[f]:
                fmap['f' + str(fnum)] = (ident, v)
                fnum += 1

    #features = dframe[dframe.Feature != 'Leaf'].Feature.unique()
    #finv = { features[i] : i for i in range(len(features)) }
    #quant = [ set(dframe[dframe.Feature == f].Split.unique()) for f in features ]
    #qmax = 1 + max([len(q) for q in quant])
    #qpad = [ sorted(q) + [1.0 for i in range(qmax - len(q))] for q in quant ]
    #qflat = [ k for q in qpad for k in q ]
    dom_min = min([min(domains[f]) for f in domains])
    dom_max = max([max(domains[f]) for f in domains])

    ## Setting up the features.
    print("include \"globals.mzn\";")
    #print("set of int: Quant = 1..{};".format(qmax))
    print("enum Feature = {{ {} }};".format(",".join(features)))
    print("set of int: Tree = 1..{};".format(len(trees)))
    print("set of int: Class = 1..{};".format(num_classes))

    print("array [Feature] of set of int: feat_dom = array1d(Feature, {});".format([ set(domains[f]) for f in range(len(features)) ]))
    #print("array [Feature, Quant] of float: Q = array2d(Feature, Quant, {});".format(qflat))
    #print("function Quant: to_quant(Feature: f, float: v) = arg_max([bool2int(v < Q[f,q]) | q in Quant]);")

    print("int: Scale = 1000;")

    print("array [int] of Feature: hyp_feature;")
    print("array [int] of int: hyp_val;")
    print("opt Class: obs_class;")

    print("constraint if not absent(obs_class) then class != deopt(obs_class) endif;")
    
    print('''array [int] of var bool: assumps = [fval[hyp_feature[h]] == hyp_val[h] | h in index_set(hyp_feature) ];''')

    print("array [Feature] of var {0}..{1}: fval; %% Decision variable.".format(dom_min,dom_max))
    print("constraint forall (f in Feature) (fval[f] in feat_dom[f]);")

    print("array [Tree] of var int: tree_score = array1d(Tree, [\n  {}]);".format(
        ",\n  ".join([make_tree(dframe, fmap, t) for t in trees])
        ))

    # print("array [Class] of var int: class_score = [ sum (t in {0} * (c-1) + 1..{0} * c) (tree_score[t]) | c in Class ];".format(trees_per_class));
    print("array [Class] of var int: class_score = [ sum (i in 1..{0}) (tree_score[{1} * (i-1) + c]) | c in Class ];".format(trees_per_class, num_classes));

    print("var Class: class = arg_max(class_score);");
    print("solve ::assume(assumps) satisfy;");

    print('''output [
     "fval = array1d(Feature, \(fval);\\nclass = \(class);\\n",
     % "treescore = \(tree_score);\\nclass_score=\(class_score);"
    ];''')
