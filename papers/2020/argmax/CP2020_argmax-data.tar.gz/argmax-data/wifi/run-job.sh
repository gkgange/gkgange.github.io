#!/bin/bash
#TIMEOUT=600
#TIMEOUT=60
#TIMEOUT=1800
# MZNC="/home/gkgange/research/solvers/libminizinc/build/minizinc --solver geas -c"
#MZNC=/home/gkgange/research/solvers/MiniZincIDE-2.3.2-bundle-linux/bin/minizinc
MZNC="/home/gkgange/research/solvers/libminizinc/build/minizinc"

SOLVER="/home/gkgange/coding/geas-dev/fzn/fzn_geas"

ARGS_BASE="-s"

#INSTANCES=$1
#shift
#
#DATE=`date +%F-%H.%M`
#RESULTS=results.${DATE}
#OUTDIR=output.${DATE}
#
#if [ -d ${OUTDIR} ]
#then
#  rm -rf ${OUTDIR}
#fi
#mkdir ${OUTDIR}
#RESULTS=$1
OUTDIR=$1
TIMEOUT=$2

MODE=$3
MZN=$4
DZN=$5

ARGS_COMMON="-s -a --time-out ${TIMEOUT}"

ARGS=${ARGS_COMMON}

MZN_ARGS="--solver geas-dev -c -Dargmax_mode=Argmax_${MODE}"

SUFFIX=${MODE}

FZN=`mktemp -ut XXXXXXXXX.fzn`
OZN=`mktemp -ut XXXXXXXXX.ozn`

${MZNC} ${MZN_ARGS} -o ${FZN} -O ${OZN} ${MZN} ${DZN}

IDENT=`basename ${MZN} .mzn`_`basename ${DZN} .dzn`
(
  echo ${MODE},`basename ${MZN} .mzn`,`basename ${DZN} .dzn`
  #echo ${p} | tr '_' ','
  echo %%%% MZN Args: ${MZN_ARGS} >> ${OUTDIR}/${IDENT}.${SUFFIX}
  echo %%%% Args: ${ARGS} > ${OUTDIR}/${IDENT}.${SUFFIX}
  ${SOLVER} ${ARGS} ${FZN} | ${MZNC} --ozn-file ${OZN} --output-time >> ${OUTDIR}/${IDENT}.${SUFFIX}
) 2>&1 | paste -s -d ','

rm ${FZN} ${OZN}
