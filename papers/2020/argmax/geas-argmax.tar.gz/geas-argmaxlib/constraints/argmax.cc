#include <geas/constraints/argmax.hpp>
#include <geas/engine/propagator_ext.h>

namespace geas {

// Normal argmax
bool int_argmax(solver_data* s, intvar z, vec<intvar>& xs) {
  // return argmax<int>::prop<intvar>::post(s, xs, z);
  return argmax<int>::simple<intvar>::post(s, xs, z);
}


// Where the elements are Boolean, and at least one is known to be true.
class argmax_bool_fix : public propagator, public prop_inst<argmax_bool_fix> {
  enum Evt { LB = 1, FIX = 2, ELT = 4 };
  watch_result wake_lb(int _c) {
    // Save the old value, so we know where to start from.
    if(! (events & LB) ) {
      events |= LB;
      old_lb = z.lb(s->wake_vals);
      queue_prop();
    }
    return Wt_Keep;
  }

  watch_result wake_fix(int _c) {
    events |= FIX;
    queue_prop();
    return Wt_Keep;
  }

  watch_result wake_elt(int idx) {
    if(idx < z.ub(s->ctx())) {
      if(! (events & ELT) ) {
        events |= ELT;
        min_idx = idx;
        queue_prop();
      } else {
        min_idx = std::min(min_idx, idx);
      }
    }
    return Wt_Keep;
  }
  watch_result wake_rem(int idx) {
    if(lb(z) != idx)
      return Wt_Keep;

    // Otherwise, act as if we just increased lb to here.
    if(! (events & LB) ) {
      events |= LB;
      old_lb = idx;
      queue_prop();
    }
    
    return Wt_Keep;
  }

  void ex_z_lb(int old_lb, pval_t p, vec<clause_elt>& expl) {
    int new_lb = z.lb_of_pval(p);
    EX_PUSH(expl, z < old_lb);
    for(int ii = old_lb; ii < new_lb; ++ii)
      EX_PUSH(expl, xs[ii]);
  }

public:
  // Assumes z is zero-indexed.
  argmax_bool_fix(solver_data* s, intvar _z, vec<patom_t>& _elts)
    : propagator(s)
    , z(_z)
    , xs(new patom_t[_elts.size()+1])
    , sz(_elts.size())
    , events(0) {
    for(int ii = 0; ii < sz; ++ii) {
      // Already true
      if(_elts[ii].lb(s->ctx())) {
        sz = ii;
        break;
      }
      xs[ii] = _elts[ii];
    }
    xs[sz] = at_True;
    if(sz < z.ub(s))
      set_ub(z, sz, reason());
  
    z.attach(E_FIX, watch<&P::wake_fix>(0));
    z.attach(E_LB, watch<&P::wake_lb>(0));
    for(int ii = 0; ii < sz; ++ii) {
      attach(s, xs[ii], watch<&P::wake_elt>(ii));
      attach(s, ~xs[ii], watch<&P::wake_rem>(ii));
    }
  }

  bool propagate(vec<clause_elt>& confl) {
    if(events & LB) {
      // Kill any elements between x[old_lb(z)] and current x[lb(z)].
      int new_lb(lb(z));
      int ii = old_lb;
      for(; ii < new_lb; ++ii) {
        if(xs[ii].ub(s->ctx())
           && !enqueue(*s, ~xs[ii], z <= ii))
          return false;
      }
      if(!xs[ii].ub(s->ctx())) {
        // Possibly adjust the LB further.
        ++ii;
        while(!xs[ii].ub(s->ctx()))
          ++ii; 
        if(!set_lb(z, ii, expl<&P::ex_z_lb>(new_lb)))
          return false;
      }
    }

    if(events & ELT) {
      // Update ub(z) to the first known true element.
      if(min_idx < ub(z)) {
        assert(xs[min_idx].lb(s->ctx()));
        if(!set_ub(z, min_idx, ~xs[min_idx]))
        return false;
      }
    }

    if(events & FIX) {
      if(!enqueue(*s, xs[lb(z)], z != lb(z)))
        return false;
    }
    return true;
  }

  void cleanup(void) {
    is_queued = false;
    events = 0;
  }

  geas::intvar z; // index of first True element
  geas::patom_t* xs; // xs[sz] is definitely true.
  int sz;

  unsigned char events;
  int old_lb;  // When lb changed, what was the old position?
  int min_idx; // If an element will pull the ub up, what is its index?
};

// Normal argmax
bool bool_first_true(solver_data* s, intvar z, vec<patom_t>& xs) {
  return argmax_bool_fix::post(s, z, xs);
}

};
