#ifndef GEAS__ARGMAX__HPP
#define GEAS__ARGMAX__HPP
// Implementation header. Shouldn't be included directly,
// instead use the declaration in builtins.h
#include <geas/solver/solver_data.h>
#include <geas/engine/propagator.h>
#include <geas/utils/intrusive-heap.h>
#include <geas/vars/intvar.h>

namespace geas {

template<class Val>
struct argmax {
  struct bound_cell {
    Val bound;
    unsigned min_pos;
    unsigned max_pos;
  };

  struct PropInfo {
    unsigned prop_index;
    unsigned prop_trigger;
  };
 
  struct By_Min {
    bound_cell* cells;
    
    bool lt(unsigned x, unsigned y) const { return cells[x].bound < cells[y].bound; }
    unsigned pos(unsigned x) const { return cells[x].min_pos; }
    void pos(unsigned x, unsigned t) { cells[x].min_pos = t; }
  };

  struct By_Max {
    bound_cell* cells;

    bool lt(unsigned x, unsigned y) const { return cells[x].bound > cells[y].bound; }
    unsigned pos(unsigned x) const { return cells[x].max_pos; }
    void pos(unsigned x, unsigned t) { cells[x].max_pos = t; }
  };


  enum { DWORD_BITS = 6 };

  inline static unsigned base(unsigned c) { return c >> DWORD_BITS; }
  inline static unsigned mask(unsigned c) { return c & ((1 << DWORD_BITS)-1); }
  inline static uint64_t bit(unsigned c) { return 1ull << mask(c); }
  inline static unsigned req_words(unsigned sz) { return (sz >> DWORD_BITS) + (mask(sz) != 0); }


  static void Fill_BV(uint64_t* start, unsigned sz) {
    memset(start, -1, sizeof(uint64_t) * req_words(sz));
    if(mask(sz))
      start[base(sz)] &= bit(sz)-1;
  }
  template<class F>
  inline static void Foreach_BV(uint64_t* b, uint64_t* e, F f, int base = 0) {
    for(; b != e; ++b) {
      uint64_t mask(*b);
      while(mask) {
        unsigned offset(__builtin_ctzll(mask));
        mask &= (mask-1);
        f(base + offset);
      }
      base += 64;
    }
  }
  template<class F>
  inline static bool Forall_BV(uint64_t* b, uint64_t* e, F f, int base = 0) {
    for(; b != e; ++b) {
      uint64_t mask(*b);
      while(mask) {
        unsigned offset(__builtin_ctzll(mask));
        mask &= (mask-1);
        if(!f(base + offset))
          return false;
      }
      base += 64;
    }
    return true;
  }

  template<class Var>
  class simple : public propagator, public prop_inst< simple<Var> > {
    typedef simple<Var> P;
    typedef prop_inst< simple<Var> > I;
   
    struct ex_info {
      int c; // Index to be explained
      int r; // Reference index (current lbi)
    };

  inline bool in_dom(unsigned c) const { return dom[base(c)] & bit(c); }
  inline bool in_rel(unsigned c) const { return rel[base(c)] & bit(c); }
  inline void rem_dom(unsigned c) {
    trail_save(s->persist, dom[base(c)], d_saved[base(c)]);
    dom[base(c)] &= ~bit(c);
  }
  inline void rem_rel(unsigned c) {
    trail_save(s->persist, rel[base(c)], r_saved[base(c)]);
    rel[base(c)] &= ~bit(c);
  }

    enum Event { UB_CHANGE = 1, UB_CHECK = 2, LB_CHANGE = 4, REM = 8 };
    inline void queue_event(Event e) {
      events |= e;
      queue_prop();
    }
    
    inline bool update_lbi(int xi) {
      if(xi == lbi) return !z_fixed;
      if(lb(xs[xi]) > lb(xs[lbi]) - (xi > lbi)) {
        set(lbi, xi);
        return true;
      }
      return false;
    }

    watch_result wake_z(int c) {
      if(in_dom(c)) {
        rem_dom(c);
        if(c == ubi) {
            queue_event(UB_CHANGE);
        } else {
            queue_event(UB_CHECK);
            ub_queue[ub_tl++] = c;
        }
      }
      return Wt_Keep;
    }
    watch_result wake_z_fix(int _z) {
      trail_change(s->persist, z_fixed, (char) 1);
      queue_event(LB_CHANGE);
      return Wt_Keep;
    }

    watch_result wake_lb(int xi) {
      if(in_rel(xi) && update_lbi(xi)) {
        queue_event(LB_CHANGE);
      }
      return Wt_Keep;
    }

    watch_result wake_ub(int c) {
      if(in_dom(c) && in_rel(c)) {
        if(c == ubi) {
            queue_event(UB_CHANGE);
        } else if(lb(xs[lbi]) + (lbi < c) > ub(xs[c])) {
          assert(rem_tl < sz);
            queue_event(REM);
            rem_queue[rem_tl++] = c;
            rem_rel(c);
        }
      }
      return Wt_Keep;
    }

    void cleanup(void) {
      is_queued = false;
      events = 0;
      ub_tl = 0;
      rem_tl = 0;
    }

    // Max lb has changed -- check if this invalidates any indices.
    bool filter_lb(vec<clause_elt>& confl) {
      Val lbv(lb(xs[lbi]));
      if(z_fixed) {
        int z_val(lb(z));
        Val z_lb(lbv + (z_val > lbi));
        if(z_lb > lb(xs[z_val]) &&
          !set_lb(xs[z_val], z_lb, this->template expl<&P::ex_lb>(lbi, expl_thunk::Ex_BTPRED)))
          return false;
        set(lbi, z_val);
        return true;
      }
      bool okay =
        Forall_BV(dom, dom+req_words(sz),
                  [this, lbv](int c) {
                    Val c_lb(lbv + (lbi < c));
                    if(ub(xs[c]) < c_lb) {
                      if(!enqueue(*s, z != c, this->template expl<&P::ex_rem>(make_expl(c, lbi), expl_thunk::Ex_BTPRED)))
                        return false;
                      rem_dom(c);
                      rem_rel(c);
                    }
                    return true;
                  });
      return okay;
    }

    int compute_ubi(void) {
      uint64_t* b(dom);
      uint64_t* e(dom + req_words(sz));
      int base(0);
      for(; b < e; ++b) {
        // Found first feasible UB.
        if(*b) {
          // Now grab the rest.
          int ubi(base + __builtin_ctzll(*b));
          Val ubv(ub(xs[ubi]));
          Foreach_BV(b, e, [this, &ubi, &ubv](int c) {
              Val ub_c(ub(xs[c]));
              if(ub_c > ubv) {
                ubi = c;
                ubv = ub_c;
              }
            }, base);
          return ubi;
        }
        base += 64;
      }
      // domain is empty. Awkward.
      return ubi;
    }

    bool filter_ub(vec<clause_elt>& confl) {
      // First, compute the new ubi.
      set(ubi, compute_ubi());
      Val ubv(ub(xs[ubi]));

      // Then, iterate over the removed indices.
      int b(0);
      int e(req_words(sz));
      int base(0);
      for(; b != e; ++b) {
        uint64_t bits(rel[b] & ~dom[b]);
        if(bits) {
          do {
            int c(base + __builtin_ctzll(bits));
            bits &= (bits-1);
            Val ub_c(ubv - (c < ubi));
            if(ub(xs[c]) > ub_c &&
               !set_ub(xs[c], ub_c, this->template expl<&P::ex_ub>(c, expl_thunk::Ex_BTPRED)))
              return false;
          } while(bits);
        }
        base += 64;
      }
      return true;
    }

    void ex_ub(int c, pval_t p, vec<clause_elt>& expl) {
      Val c_ub(xs[c].ub_of_pval(p));
      // Upper bound is slightly annoying.
      EX_PUSH(expl, z == c);
      for(unsigned ii = 0; ii < sz; ++ii) {
        if(ii == c) continue;

        Val i_ub(ub(xs[ii]));
        // Either is below c_ub, or is not in dom(z).
        if(i_ub > c_ub + (c < ii)) {
          EX_PUSH(expl, z == ii);
        } else {
          EX_PUSH(expl, xs[ii] > c_ub + (c < ii));
        }
      }
    }

    void ex_lb(int r, pval_t p, vec<clause_elt>& expl) {
      // What value are we explaining?
      int z_val(lb(z));

      Val c_lb(xs[z_val].lb_of_pval(p));
      EX_PUSH(expl, z != z_val);
      EX_PUSH(expl, xs[r] < c_lb - (r < z_val));
    }

    void ex_rem(int eid, pval_t p, vec<clause_elt>& expl) {
      const ex_info& ex(exs[eid]);
      Val c_lb(ub(xs[ex.c]));
      EX_PUSH(expl, xs[ex.c] > c_lb);
      EX_PUSH(expl, xs[ex.r] <= c_lb - (ex.r < ex.c));
    }

    int make_expl(int c, int r) {
      int id(exs.size());
      save(exs._size(), exs_saved);
      exs.push(ex_info { c, r });
      return id;
    }

  public:
    simple(solver_data* s, vec<intvar>& _xs, intvar _z)
      : propagator(s)
      , sz(_xs.size())
      , z(_z)
      , xs(new intvar[_xs.size()])
      , lbi(0), ubi(0)
      , dom(new uint64_t[req_words(sz)])
      , d_saved(new char[req_words(sz)])
      , rel(new uint64_t[req_words(sz)])
      , r_saved(new char[req_words(sz)])
      , z_fixed(0)
      , dom_support(0)

      , events(0)
      , rem_queue(new int[sz]), rem_tl(0)
      , ub_queue(new int[sz]), ub_tl(0)
      , exs_saved(0)
    {

      // Now initialize everything.
      // Fill dom and rel.
      make_eager(z);
      Fill_BV(dom, sz);
      Fill_BV(rel, sz);
      memset(d_saved, 0, req_words(sz));
      memset(r_saved, 0, req_words(sz));

      // Fill in xs, and initialize lbi/ubi.
      for(int ii : irange(sz))
        xs[ii] = _xs[ii];

      // Compute lbi.
      int lbi_(0);
      Val lbv(lb(xs[0]));
      for(int ii : irange(1, sz)) {
        if(lb(xs[ii]) > lbv) {
          lbi_ = ii;
          lbv = lb(xs[ii]);
        }
      }
      lbi.x = lbi_;

      // And ubi.
      unsigned ii(0);
      for(; ii < sz; ++ii) {
        if(z.in_domain(s->ctx(), ii))
          break;
      }
      assert(ii < sz);
      int ubi_(ii);
      Val ubv(ub(xs[ii]));
      for(++ii; ii < sz; ++ii) {
        if(ub(xs[ii]) > ubv) {
          ubi_ = ii;
          ubv = ub(xs[ii]);
        }
      }
      ubi.x = ubi_;

      // Now do some initial filtering, and update
      // dom/rel.
      for(int ii : irange(sz)) {
        // Check if the index is definitely irrelevant.
        if(ub(xs[ii]) < lbv + (lbi < ii)) {
          if(z.in_domain(s->ctx(), ii)
             && !enqueue(*s, z != ii, reason()))
            throw RootFail { };
          rem_dom(ii);
          rem_rel(ii);
          continue;
        }
        // Otherwise, check whether it's in dom(z).
        if(z.in_domain(s->ctx(), ii)) {
          // Feasible, need to attach to both lb and ub.
          xs[ii].attach(E_UB, this->template watch<&P::wake_ub>(ii));
        } else {
          // Not in the domain, but possibly relevant.
          rem_dom(ii);
        }
        xs[ii].attach(E_LB, this->template watch<&P::wake_lb>(ii));
      }
      // And attach to z. (This is a horrible workaround because domain-based attachment
      // is unreliable).
      int l(lb(z));
      int u(ub(z));
      for(int ii = l; ii <= u; ++ii)
        attach(s, z != ii, this->template watch<&P::wake_z>(ii, P::Wt_IDEM));
      z.attach(E_FIX, this->template watch<&P::wake_z_fix>(0));
    }

    ~simple(void) {
      delete[] xs;
      delete[] dom;
      delete[] d_saved;
      delete[] rel;
      delete[] r_saved;
    }

    // Ugly hack, to deal with late wipeout detection.
    bool dom_nonempty(void) {
      if(dom[dom_support])
        return true;

      for(int ii = 0; ii < req_words(sz); ++ii) {
        if(dom[ii]) {
          dom_support = ii;
          return true;
        }
      }
      return false;
    }
    
    bool propagate(vec<clause_elt>& confl) {
      // Check the events. Check LB first, because that
      // can remove indices.
      if(events & LB_CHANGE) {
        // This will also update lb(xs[z]) if fixed.
        if(!filter_lb(confl))
          return false;

        if(!dom_nonempty()) return true;
      } else if(events & REM) {
        // Don't need to check -- we checked LB on wakeup.
        for(int c : range(rem_queue, rem_queue + rem_tl)) {
          if(in_dom(c) &&
             !enqueue(*s, z != c, this->template expl<&P::ex_rem>(make_expl(c, lbi), expl_thunk::Ex_BTPRED)))
            return false;
          // Now remove it from the domain, and from the relevance.
          rem_dom(c);
          rem_rel(c);
        }
        if(!dom_nonempty()) return true;
      }
      assert(dom_nonempty());

      // Now check UB effects.
      if(events & UB_CHANGE) {
        // Value of ub(xs[ubi]) has changed. Compute the new one,
        // and check for removals.
        if(!filter_ub(confl))
          return false;
      } else if(events & UB_CHECK) {
        // Value (and index) of ubi hasn't changed.
        Val ubv(ub(xs[ubi]));
        for(int c : range(ub_queue, ub_queue + ub_tl)) {
          // Compute the effective ub of c.
          Val c_ub(ubv - (c < ubi));
          if(ub(xs[c]) > c_ub
             && !set_ub(xs[c], c_ub, this->template expl<&P::ex_ub>(c, expl_thunk::Ex_BTPRED))) {
            return false;
          }
        }
      }
      return true;
    }

      // DATA
      unsigned sz;
      intvar z;
      Var* xs;

      // Persistent state.
      trailed<int> lbi; // argmax({lb(x) | x in X})
      trailed<int> ubi; // arg max({ub(x) | x in dom(z)})

      uint64_t* dom;
      char* d_saved;
      uint64_t* rel;
      char* r_saved;

      char z_fixed;

    // Quasi-persistent stuff
    int dom_support; // Block with non-empty domain.

      // Transient stuff: for wakeup
      unsigned char events;
      int* rem_queue;
      int rem_tl;
      int* ub_queue;
      int ub_tl;

      // If a variable was removed by domain,
      // Which 
    vec<ex_info> exs;
    char exs_saved;
  };

  template<class Var>
  class prop : public propagator, public prop_inst< prop<Var> > {
    typedef prop<Var> P;
    typedef prop_inst< prop<Var> > I;
    
      enum Event { MAX_LB = 1, MAX_UB = 2, REM_IDX = 4 };
      enum State { MAX_HEAP_OKAY = 1, MIN_HEAP_OKAY = 2 };

      inline bool in_dom(unsigned c) const { return indices[base(c)] & bit(c); }
      inline bool in_rel(unsigned c) const { return relevant[base(c)] & bit(c); }
      inline void rem_dom(unsigned c) {
        trail_save(s->persist, indices[base(c)], d_saved[base(c)]);
        indices[base(c)] &= ~bit(c);
      }
      inline void rem_rel(unsigned c) {
        trail_save(s->persist, relevant[base(c)], r_saved[base(c)]);
        relevant[base(c)] &= ~bit(c);
      }

      watch_result wake_z(int _z, int64_t c) {
        if(in_dom(c)) {
          rem_dom(c);
          if(heap_state & MAX_HEAP_OKAY)
            ub_max_heap.remove(c);

          if(c == ub_max_supp) {
            events |= MAX_UB;
            queue_prop();
          }
        }
        return Wt_Keep;
      }

      watch_result wake_x_lb(int xi) {
        // Ignore any irrelevant indices.
        if(!in_rel(xi))
          return Wt_Keep;

        Val k(lb(xs[xi]));
        if(k > lb_max) {
          set(lb_max, k);
          if(k > ub_min) {
            events |= MAX_LB;
            queue_prop();
          }
        }
        return Wt_Keep;
      }

      watch_result wake_x_ub(int xi) {
        if(!in_rel(xi))
          return Wt_Keep;

        Val k(ub(xs[xi]));
        if(heap_state) {
          ub_cell[xi].bound = k;
          if(heap_state & MAX_HEAP_OKAY)
            ub_max_heap.increase(xi);
        }
        if(in_dom(xi)) {
          // Can only affect ub_max if this was
          // previously ub_max_supp.
          unsigned char evt(0);
          if(xi == ub_max_supp)
            evt |= MAX_UB;

          Val v(ub(xs[xi]));

          if(v < lb_max) {
            evt |= REM_IDX;
            rem_dom(xi);
            rem_rel(xi);
            if(heap_state & MIN_HEAP_OKAY)
              ub_min_heap.remove(xi);
            (*kill_tl) = xi;
            ++kill_tl;
          } else {
            if(heap_state & MIN_HEAP_OKAY)
              ub_min_heap.decrease(xi);
            if(v < ub_min)
              set(ub_min, v);
          }
          if(evt) {
            events |= evt;
            queue_prop();
          }
        } else if (k < lb_max) {
          // If it has dropped below lb_max, it can't
          // invalidate any indices.
          // Could remove it from ub_max_heap at this point.
          rem_rel(xi);
        }
        return Wt_Keep;
      }

      // This contains only the domain values.
      void init_ub_min(void) {
        if(!heap_state) {
          s->persist.bt_flags.push(&heap_state);
          Foreach_BV(relevant, relevant+base(sz-1)+1,
            [this](unsigned c) { ub_cell[c].bound = ub(xs[c]); });
        }
        heap_state |= MIN_HEAP_OKAY;

        Foreach_BV(indices, indices+base(sz-1)+1,
          [this](unsigned c) { ub_min_heap.add_raw(c); });
        ub_min_heap.heapify();
      }

      void init_ub_max(void) {
        if(!heap_state) {
          s->persist.bt_flags.push(&heap_state);
          Foreach_BV(relevant, relevant+base(sz-1)+1,
            [this](unsigned c) { ub_cell[c].bound = ub(xs[c]); });
        }
        heap_state |= MAX_HEAP_OKAY;
        
        Foreach_BV(relevant, relevant+base(sz-1)+1,
          [this](unsigned c) { ub_max_heap.add_raw(c); });
        ub_max_heap.heapify();
        
        // Now remove any binding, but out-of-domain, indices.
        active.clear();
        unsigned k(ub_max_heap.top());
        while(!in_dom(k)) {
          ub_max_heap.pop();
          active.pop();
          k = ub_max_heap.top();
        }
      }

      void ex_lb(int pi, pval_t p, vec<clause_elt>& expl) {
        unsigned xi(prop_info[pi].prop_index);
        unsigned t(prop_info[pi].prop_trigger);
        Val ex_val(xs[xi].lb_of_pval(p));
        EX_PUSH(expl, z != xi);
        EX_PUSH(expl, xs[t] < ex_val);
      }
      void ex_ub(int pi, pval_t p, vec<clause_elt>& expl) {
        PropInfo pr(prop_info[pi]);
        unsigned xi(pr.prop_index);
        Val ex_val(xs[xi].ub_of_pval(p));
        GEAS_NOT_YET;
      }
      void ex_neq(int pi, pval_t p, vec<clause_elt>& expl) {
        // Only cause of removal is ub(x[i]) < lb(x[j]) for some j.

        GEAS_NOT_YET;
      }
      
    public:
      prop(solver_data* s, vec<Var>& _xs, intvar _z)
        : propagator(s)
        , sz(_xs.size())
        , z(_z)
        , xs((Var*) malloc(sizeof(Var) * sz))
        , ub_max_supp(0), lb_max(0), ub_min(0)
        , ub_cell(new bound_cell[sz])
        , ub_min_heap(By_Min {ub_cell}), ub_max_heap(By_Max {ub_cell})
        , kill_queue(new unsigned[sz]), kill_tl(kill_queue) {
        // Fill xs, and attach
        Var* p(xs);
        unsigned xi(0);
        for(const Var& x : _xs) {
          new (p) Var(x);
          p->attach(E_LB, this->template watch<&P::wake_x_lb>(xi, I::Wt_IDEM));
          p->attach(E_UB, this->template watch<&P::wake_x_ub>(xi, I::Wt_IDEM));
          ++xi, ++p;
        }
        z.attach_rem(this->template watch_val<int64_t, &P::wake_z>(0, I::Wt_IDEM));
        z.attach(this->template watch<&P::wake_z_lb>(0, I::Wt_IDEM));
        z.attach(this->template watch<&P::wake_z_ub>(0, I::Wt_IDEM));

        // Now initialize the persistent state.
        // First the cached lb/ub values.
        unsigned umax_supp(0);
        Val umin(ub(xs[0]));
        Val umax(umin);
        Val lmax(lb(xs[0]));
        
        for(unsigned xi : irange(1, sz)) {
          Val l(lb(xs[xi]));
          Val u(ub(xs[xi]));

          if(lmax < l)
            lmax = l;
          if(umax < u) {
            umax = u;
            umax_supp = xi;
          }
        }
        ub_max_supp.x = umax_supp;
        lb_max.x = lmax;
        ub_min.x = umin;

        // And the z domain.
        // TODO
      }

      bool propagate(vec<clause_elt>& confl) {
        if(events & REM_IDX) {
          if(!prop_removed())
            return false;
        }
        if(events & MAX_LB) {
          // Lower bound of xs has increased, above our
          // (believed) min ub.
          if(!prop_notin())
            return false;
          // After prop_notin, ub_min_heap is consistent.
          unsigned c(ub_min_heap.top());
          set(ub_min, ub_cell[c].bound);
        }

        if(events & MAX_UB) {
          if(!prop_down())
            return false;
          // Likewise, after prop_down, ub_max_heap is consistent.
          set(ub_max_supp, ub_max_heap.top());
        }
        return true;
      }

      void cleanup(void) {
        events = 0;
        kill_tl = kill_queue;
      }

    protected:
      // The max over dom(z) should be larger than the max
      // over non-domain values.
      bool prop_down(void) {
        // ub_max should contain (at least) everything
        // in Dom(z), so should be non-empty.
        assert(!ub_max_heap.empty());
        // Now, see if anything has a higher upper bound.
        unsigned k(ub_max_heap.top());
        while(!in_dom(k)) {
          if(!set_ub(xs[k], lb_max, this->template expl<&P::ex_ub>(k, expl_thunk::Ex_BTPRED)))
            return false;
          active.push(k);
          assert(!ub_max_heap.empty());
          k = ub_max_heap.top();
        }

        // Now tighten any variables which we believe are tight.
        Val max_in_dom(ub_cell[k].bound);
        for(unsigned c : active) {
          if(ub(xs[c]) > max_in_dom
             && !set_ub(xs[c], max_in_dom, this->template expl<&P::ex_ub>(k, expl_thunk::Ex_BTPRED)))
            return false;
        }
        
        set(ub_max_supp, k);
        // set(max_in, max_in_dom);

        return true;
      }

      // Remove no-longer-feasible indices from
      // consideration.
      bool prop_notin(void) {
        // ub_min should, likewise, contain everything
        // in Dom(z), so should not be empty.
        assert(!ub_min_heap.empty());
        
        unsigned k(ub_min_heap.top());
        while(ub_cell[k].bound < lb_max) {
          ub_min_heap.pop();

          if(!enqueue(*s, z != k, this->template expl<&P::ex_neq>(k)))
            return false;
          assert(!ub_min_heap.empty());

          // Neither in-domain or relevant.
          rem_dom(k);
          rem_rel(k);

          // Could remove it from the other heap. But it's smaller
          // than all the in-domain values, so we can just leave it there.
          // The next time we backtrack somewhere around this point, it'll
          // be removed.
          // TODO: Profile
          k = ub_min_heap.top();
        }
        return true;
      }

      bool prop_removed(void) {
        unsigned* p(kill_queue);
        for(; p != kill_tl; ++p) {
          if(!enqueue(*s, z != *p, this->template expl<&P::ex_neq>(*p)))
            return false;
        }
        kill_tl = kill_queue;
        return true;
      }

      unsigned sz;
      intvar z;
      Var* xs;

      // Persistent state.
      trailed<unsigned> ub_max_supp; // arg max({ub(x) | x in dom(z)})
      // So long as ub_min > lb_max, we don't need to check
      // for invalidated indices.
    trailed<unsigned> lbi; // argmax({lb(x) | x in X})
      trailed<Val> lb_max; // max({lb(x) | x in X})
      trailed<Val> ub_min; // min({ub(x) | x in dom(z)})

      uint64_t* indices;
      char* d_saved;

      uint64_t* relevant;
      char* r_saved;

      // Quasi-persistent state
      bound_cell* ub_cell; 
      IntrusiveHeap<unsigned, By_Min> ub_min_heap;
      IntrusiveHeap<unsigned, By_Max> ub_max_heap; 
      char heap_state; // Which of the heaps is consistent?

      // Some subtlety here: if ub_max.top() is in Dom(z),
      // that's the max.
      // If it isn't, we pop it and shift it to active.
      vec<unsigned> active;

      // Transient stuff: for wakeup
      unsigned char events;
      unsigned* kill_queue;
      unsigned* kill_tl;

      // If a variable was removed by domain,
      // Which 
      vec<PropInfo> prop_info;
  };
};

};
#endif
